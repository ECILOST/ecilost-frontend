/**
 * Configuracion de la aplicacion, leida una sola vez y tipada, igual que el
 * `src/config/*.config.ts` de los servicios.
 *
 * Ningun otro archivo toca `import.meta.env`: asi una variable mal escrita se ve aqui y no
 * en la pantalla que la necesitaba, y cambiar de despliegue es cambiar un archivo.
 */
export interface AppConfig {
  readonly services: {
    /** ecilost-auth-service. Emite la sesion y el access token. */
    readonly auth: string;
    /** ecilost-catalog-service. Objetos, lotes y multimedia. */
    readonly catalog: string;
    /** ecilost-wallet-service. Saldo en ECICoin y recargas. */
    readonly wallet: string;
    /** ecilost-auction-service. Salas, rondas y pujas. */
    readonly auction: string;
    /** ecilost-engagement-service por HTTP: bandeja de notificaciones. */
    readonly engagement: string;
    /**
     * Origen del canal en vivo de engagement (Socket.IO, namespace `/realtime`). Vacio es el
     * mismo origen de la aplicacion, que en desarrollo republica el proxy de Vite.
     */
    readonly realtime: string;
  };
  /**
   * Subastas del estudiante en memoria, con rivales simulados, en vez de contra
   * ecilost-auction-service. Para demostrar las pantallas sin levantar el backend.
   */
  readonly auctionsDemo: boolean;
}

/**
 * Por defecto apuntan al proxy de Vite y no a `localhost:3000`: la cookie de sesion es
 * httpOnly y de primera parte, y solo viaja si el navegador ve un mismo origen.
 *
 * La base de auth incluye el prefijo `/auth` porque asi se emite la cookie (`Path=/auth`),
 * de modo que un `/token` en el adaptador es el `POST /auth/token` del servicio.
 */
export const config: AppConfig = {
  services: {
    auth: import.meta.env.VITE_AUTH_BASE_URL ?? '/auth',
    catalog: import.meta.env.VITE_CATALOG_BASE_URL ?? '/api/catalog',
    wallet: import.meta.env.VITE_WALLET_BASE_URL ?? '/api/wallet',
    auction: import.meta.env.VITE_AUCTION_BASE_URL ?? '/api/auction',
    engagement: import.meta.env.VITE_ENGAGEMENT_BASE_URL ?? '/api/engagement',
    realtime: import.meta.env.VITE_REALTIME_URL ?? '',
  },
  // Solo el texto exacto la activa: una variable mal escrita no debe esconder el backend real.
  auctionsDemo: import.meta.env.VITE_AUCTIONS_DEMO === 'true',
};
