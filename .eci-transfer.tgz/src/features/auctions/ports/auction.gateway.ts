import type {
  AppNotification,
  AuctionItem,
  LiveRoom,
  MyBid,
  Room,
  RoomChat,
  RoomSummary,
  SealedResults,
} from '../model/auction';

/**
 * Lo que las pantallas de subasta necesitan, sin decir por donde llega.
 *
 * Lo cumplen dos adaptadores: `createHttpAuctionGateway`, contra ecilost-auction-service
 * (salas y admision hoy; estado y pujas despues) y en adelante ecilost-engagement-service
 * (canal `/realtime` y notificaciones); y `createDemoAuctionGateway`, en memoria, para
 * demostrar las pantallas sin backend. Cambiar de uno a otro no toca ninguna pantalla.
 */
export interface AuctionGateway {
  /** Objetos de todas las salas, para el catalogo y la portada. */
  items(): Promise<AuctionItem[]>;
  item(id: string): Promise<AuctionItem>;

  room(id: string): Promise<Room>;
  /** `POST /rooms/:id/participants`. Solo antes de que la sala empiece. */
  joinRoom(id: string): Promise<Room>;

  /** `GET /rooms/:id/state`: lo que hay que pintar al entrar o al reconectar. */
  liveRoom(id: string): Promise<LiveRoom>;
  /**
   * `POST /rounds/:roundId/bids` sobre la ronda que el estudiante estaba viendo (HU-25). Si
   * la sala ya paso a otro objeto (por ejemplo, alguien lo compro), el servicio la rechaza en
   * vez de pujar por el siguiente.
   */
  placeBid(roomId: string, roundId: string, amount: number): Promise<LiveRoom>;
  /**
   * `POST /rounds/:roundId/buy-now` (HU-24). Va a la ronda que el estudiante estaba viendo,
   * no a la activa al confirmar: si la sala ya cambio de objeto, el servicio la rechaza en vez
   * de comprar otro objeto.
   */
  buyNow(roomId: string, roundId: string): Promise<LiveRoom>;
  /** `PUT /rounds/:roundId/auto-bid` sobre la ronda que se estaba viendo, como `placeBid`. */
  setAutoBid(
    roomId: string,
    roundId: string,
    config: { enabled: boolean; limit: number },
  ): Promise<LiveRoom>;
  /** Subastas dinamicas, holandesa: `POST /rounds/:roundId/dutch-claim` ("Lo quiero"). */
  dutchClaim(roomId: string, roundId: string): Promise<LiveRoom>;
  /** Subastas dinamicas, sobre cerrado: `POST /rounds/:roundId/sealed-bid`. Una sola vez. */
  sealBid(roomId: string, roundId: string, amount: number): Promise<LiveRoom>;
  /** Subastas dinamicas: `GET /rounds/:roundId/sealed-results`, cuando la ronda ya cerro. */
  sealedResults(roundId: string): Promise<SealedResults>;
  /**
   * Cambios en vivo de la sala (precio, contador, transicion de ronda). Devuelve la funcion
   * para dejar de escuchar. Es el equivalente del canal de Socket.IO de engagement.
   */
  subscribe(roomId: string, listener: (state: LiveRoom) => void): () => void;

  /**
   * Chat de la sala en curso (engagement, `chat.*`). Escriben solo los participantes
   * admitidos antes del inicio; el funcionario dueño lo lee. Entrega el chat entero en cada
   * cambio y devuelve la funcion para dejar de escuchar.
   */
  subscribeChat(roomId: string, listener: (chat: RoomChat) => void): () => void;
  /** Envia un mensaje al chat. Si engagement lo rechaza, falla con `ChatSendError`. */
  sendChatMessage(roomId: string, text: string): Promise<void>;

  roomSummary(id: string): Promise<RoomSummary>;
  myBids(): Promise<MyBid[]>;
  notifications(): Promise<AppNotification[]>;
  markNotificationsRead(): Promise<void>;
}
