import { APP_TIME_ZONE, bogotaDay } from '@/shared/format/date';

/**
 * Reglas de la subasta que la interfaz necesita conocer para no hacer adivinar a nadie.
 */

/**
 * Lo minimo que una puja debe superar al precio vigente cuando la ronda ya tiene lider. Es
 * la regla de ecilost-auction-service, y el demo la imita.
 */
export const BID_INCREMENT = 100;

/** Por debajo de este margen el reloj pasa a "ultimos segundos". */
export const LAST_SECONDS_MS = 10_000;

/**
 * Anti-sniping (HU-23): una puja aceptada cuando falta menos que esto lleva el cierre a
 * "ahora + este margen". Es la regla de ecilost-auction-service; aqui solo se avisa.
 */
export const ANTI_SNIPING_WINDOW_MS = 60_000;

/**
 * HU-25: la ronda que se estaba viendo acaba de cerrarse porque otro participante la compro
 * de inmediato. Devuelve esa ronda tal como quedo cerrada, para avisarlo; si no, `null`.
 * Quien la compro no recibe este aviso: a el se le dice que gano.
 */
export function roundSoldToSomeoneElse<
  R extends {
    id: string;
    status: string;
    closeReason: string | null;
    wonByMe: boolean;
  },
>(shownBefore: { id: string } | null, roundsNow: R[]): R | null {
  if (!shownBefore) return null;
  const closed = roundsNow.find((round) => round.id === shownBefore.id);
  // Una holandesa que otro pidio ("Lo quiero") tambien se vendio antes de que venciera.
  return closed &&
    closed.status === 'CLOSED' &&
    (closed.closeReason === 'BUY_NOW' || closed.closeReason === 'DUTCH_CLAIM') &&
    !closed.wonByMe
    ? closed
    : null;
}

/** Cuanto se deja a la vista el aviso de que el cierre se extendio. */
export const EXTENSION_NOTICE_MS = 6_000;

export function nextBidFor(currentPrice: number): number {
  return currentPrice + BID_INCREMENT;
}

/**
 * La puja minima: la primera de la ronda debe alcanzar el precio minimo; las siguientes, el
 * vigente mas `BID_INCREMENT`. Por encima de eso el estudiante elige el monto.
 */
export function minimumBid(round: {
  startingPrice: number;
  currentPrice: number;
  hasBids: boolean;
}): number {
  return round.hasBids
    ? round.currentPrice + BID_INCREMENT
    : round.startingPrice;
}

/**
 * Lo que una puja suma a lo reservado en wallet. Wallet guarda una sola reserva por persona
 * y ronda, y cada puja la reemplaza por su monto: quien ya lidera solo compromete la
 * diferencia con su puja vigente (de 500 a 600 reserva 100 mas, no 600). Quien fue superado
 * ya tiene su reserva liberada y compromete el monto entero.
 */
export function coinsToCommit(
  amount: number,
  round: { leading: boolean; myHighestBid: number | null },
): number {
  if (!round.leading || round.myHighestBid === null) return amount;
  return Math.max(0, amount - round.myHighestBid);
}

const pad = (value: number) => String(value).padStart(2, '0');

/** `08:21` bajo una hora, `02:34:16` por encima. Nunca negativo. */
export function formatCountdown(ms: number, forceHours = false): string {
  const total = Math.max(0, Math.ceil(ms / 1000));
  const hours = Math.floor(total / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  const seconds = total % 60;
  if (hours > 0 || forceHours)
    return `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`;
  return `${pad(minutes)}:${pad(seconds)}`;
}

const TIME = new Intl.DateTimeFormat('es-CO', {
  hour: 'numeric',
  minute: '2-digit',
  timeZone: APP_TIME_ZONE,
});
const DAY = new Intl.DateTimeFormat('es-CO', {
  day: 'numeric',
  month: 'short',
  timeZone: APP_TIME_ZONE,
});

/** "Mañana · 10:00 a. m.", "Hoy · 3:00 p. m.", "12 abr · 11:20 a. m." */
export function formatWhen(iso: string, now = new Date()): string {
  const date = new Date(iso);
  // Hoy y mañana son los de Bogota, como la hora que se muestra al lado.
  const days = bogotaDay(date.getTime()) - bogotaDay(now.getTime());
  const time = TIME.format(date);
  if (days === 0) return `Hoy · ${time}`;
  if (days === 1) return `Mañana · ${time}`;
  return `${DAY.format(date)} · ${time}`;
}

/** "Hace 12 s", "Hace 4 min", "Hace 2 h". */
export function formatAgo(iso: string, now = Date.now()): string {
  const seconds = Math.max(
    0,
    Math.round((now - new Date(iso).getTime()) / 1000),
  );
  if (seconds < 60) return `Hace ${seconds} s`;
  const minutes = Math.round(seconds / 60);
  if (minutes < 60) return `Hace ${minutes} min`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `Hace ${hours} h`;
  return `Hace ${Math.round(hours / 24)} d`;
}

export const roomNumber = (name: string) => name.replace(/^Sala\s+/i, '');

/** Fraccion de la ronda que queda (0..1), para el aro del reloj. */
export function roundProgress(
  startedAt: string | null | undefined,
  endsAt: string | null | undefined,
  remainingMs: number,
): number {
  if (!startedAt || !endsAt) return 0;
  const total = new Date(endsAt).getTime() - new Date(startedAt).getTime();
  return total > 0 ? remainingMs / total : 0;
}

/**
 * Dias que tiene quien gana para reclamar el objeto en la oficina, como lo dice el aviso del
 * diseño. Ningun servicio publica ni hace cumplir este plazo todavia: si se vuelve una regla
 * del negocio, debe salir de auction o engagement y no de aqui.
 */
export const CLAIM_WINDOW_DAYS = 7;

const CLAIM_DATE_FORMAT = new Intl.DateTimeFormat('es-CO', {
  day: 'numeric',
  month: 'long',
  timeZone: APP_TIME_ZONE,
});

/** Fecha limite para reclamar un objeto ganado en `wonAt` (milisegundos, hora del servidor). */
export function claimDeadline(wonAt: number): string {
  return CLAIM_DATE_FORMAT.format(
    new Date(wonAt + CLAIM_WINDOW_DAYS * 86_400_000),
  );
}
