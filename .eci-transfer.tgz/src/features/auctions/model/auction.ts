import type { MedalId } from '@/features/gamification/model/gamification';
/**
 * Contratos de las subastas tal como los consume la interfaz.
 *
 * Todavia no calcan un DTO: ecilost-auction-service publica salas, rondas y pujas, y
 * ecilost-engagement-service el canal en vivo y las notificaciones, pero la conexion del
 * front con ambos esta pendiente. Mientras tanto los sirve el adaptador de demostracion
 * (`api/demo-auction.gateway.ts`) y estos tipos son el acuerdo entre pantallas y adaptador.
 *
 * Los importes van como `number` porque el adaptador de demostracion no tiene decimales;
 * cuando llegue el adaptador HTTP se revisara si conviene cadena, como en la billetera.
 */

export type RoomStatus = 'SCHEDULED' | 'ACTIVE' | 'CLOSED';
export type RoundStatus = 'SCHEDULED' | 'ACTIVE' | 'CLOSED';

/** Como se ve un objeto desde el catalogo de subastas. */
export type AuctionItemStatus = 'LIVE' | 'UPCOMING' | 'CLOSED';

export interface AuctionItem {
  id: string;
  name: string;
  description: string;
  category: string;
  condition: string;
  imageUrl: string | null;
  roomId: string;
  roomName: string;
  /** Posicion del objeto dentro de la sala (1..n) y cuantos tiene la sala. */
  position: number;
  roomSize: number;
  status: AuctionItemStatus;
  currentPrice: number;
  nextBid: number;
  buyNowPrice: number | null;
  /** Cuando empieza la sala a la que pertenece. */
  startsAt: string;
  /** Solo si esta en subasta: cuando termina su ronda. */
  endsAt: string | null;
  roundStartedAt: string | null;
  awarded: boolean;
}

export interface Round {
  id: string;
  position: number;
  itemId: string;
  itemName: string;
  /** Primera foto del objeto en catalog, o `null` si no tiene (o es un lote). */
  imageUrl: string | null;
  status: RoundStatus;
  basePrice: number;
  currentPrice: number;
  /**
   * Lo minimo que se puede pujar ahora (ver `minimumBid`). Lo calcula el adaptador y no la
   * pantalla, porque depende de si ya hay pujas y eso solo lo sabe quien habla con el
   * servicio.
   */
  minimumBid: number;
  currentBidderId: string | null;
  startedAt: string | null;
  endsAt: string | null;
  maximumEndsAt: string | null;
  buyNowPrice: number | null;
  /** Cierto si quien mira lleva la puja mas alta. */
  leading: boolean;
  /** La puja mas alta de quien mira en esta ronda, si pujo. */
  myHighestBid: number | null;
  /** Solo cerrada: si la gano quien mira. */
  wonByMe: boolean;
  /**
   * Solo cerrada: `BUY_NOW` si alguien la compro de inmediato (HU-25), `DUTCH_CLAIM` si en una
   * holandesa alguien pulso "Lo quiero".
   */
  closeReason: 'EXPIRED' | 'BUY_NOW' | 'DUTCH_CLAIM' | null;
  /** Solo cerrada: si se adjudico o quedo desierta. Es publico: no dice a quien. */
  result: 'AWARDED' | 'DESERTED' | null;
  /** Subastas dinamicas: como se juega. Sin ruleta, siempre `CLASSIC`. */
  mode: RoundMode;
  /** La ruleta ya decidio el modo de esta ronda. */
  modeLocked: boolean;
  /** Comodines seguidos que lleva la ruleta de esta ronda. */
  wildcardSpins: number;
  /** Solo holandesa: como baja el precio. */
  dutch: DutchSchedule | null;
  /** Solo sobre cerrado: cuantos sobres hay y el de quien mira. */
  sealed: { count: number; mine: number | null } | null;
  /**
   * Solo lote misterioso que quien mira no gano: las pistas. El nombre y la foto de la ronda
   * no se conocen (catalog los oculta), asi que la pantalla pinta esto en su lugar.
   */
  mystery: { entries: MysteryEntry[] } | null;
}

export type RoundMode = 'CLASSIC' | 'DUTCH' | 'SEALED' | 'MYSTERY';
export type SpinSegment = 'DUTCH' | 'SEALED' | 'MYSTERY' | 'WILDCARD';

/** Holandesa: arranca en `startPrice` y baja `step` cada `intervalSeconds` hasta `floorPrice`. */
export interface DutchSchedule {
  startPrice: number;
  floorPrice: number;
  step: number;
  intervalSeconds: number;
}

export type MysteryEntry =
  | { kind: 'ITEM'; category: string; condition: string; clues: string[] }
  | { kind: 'LOT'; itemCount: number; categories: string[]; clues: string[] };

/** Apertura de sobres de una ronda de sobre cerrado ya cerrada. */
export interface SealedResults {
  roundId: string;
  sealedCount: number;
  ranking: Array<{ rank: number; amount: number; mine: boolean; winner: boolean }>;
  myRank: number | null;
}

export interface Room {
  id: string;
  name: string;
  title: string;
  status: RoomStatus;
  startsAt: string;
  capacity: number;
  admitted: number;
  /** Cierto si quien mira fue admitido antes del inicio y por tanto puede pujar. */
  isParticipant: boolean;
  /** Cierto si quien mira es el funcionario que programo la sala: la sigue, no puja. */
  isOwner?: boolean;
  /** Subastas dinamicas: la ruleta de modalidades esta activa. */
  dynamicModesEnabled: boolean;
  rounds: Round[];
  /** Hora del servidor al leer la sala, para contar hacia su inicio sin el reloj local. */
  serverTime?: string;
}

/** Un mensaje del chat de la sala. El autor va como alias: nunca se publica su userId. */
export interface ChatMessage {
  id: string;
  alias: string;
  body: string;
  at: string;
  /** Lo escribio quien mira. */
  mine: boolean;
  /**
   * Medallas que luce el autor junto al alias (hasta dos). Las añade engagement desde el
   * perfil de quien escribe, sin revelar quien es: solo viajan los identificadores.
   */
  badges?: MedalId[];
}

/**
 * Por que no se puede usar el chat: `not-participant` (no entro antes del inicio),
 * `not-open` (la sala no esta en curso) o cualquier fallo del canal.
 */
export type ChatUnavailableReason =
  'not-participant' | 'not-open' | 'unavailable';

/** Lo que pinta el chat de la sala en curso. */
export interface RoomChat {
  status: 'connecting' | 'ready' | 'unavailable';
  /** Escriben solo los participantes y solo con la sala en curso; el dueño solo lee. */
  canWrite: boolean;
  /** El alias de quien mira, si participa. */
  alias: string | null;
  messages: ChatMessage[];
  reason?: ChatUnavailableReason;
}

/** Modalidades de la ruleta en el orden de sus segmentos. */
export const SPIN_SEGMENTS: readonly SpinSegment[] = ['DUTCH', 'SEALED', 'MYSTERY', 'WILDCARD'];

export interface Bid {
  id: string;
  alias: string;
  amount: number;
  at: string;
  mine: boolean;
  /** Medallas del postor, si el servicio las manda junto a la puja. */
  badges?: MedalId[];
}

export type RoomActivityKind =
  | 'BID'
  | 'OUTBID'
  | 'AWARDED'
  | 'STARTED'
  /** Una ronda cerro sin pujas. */
  | 'DESERTED';

export interface RoomActivity {
  id: string;
  kind: RoomActivityKind;
  text: string;
  at: string;
}

export interface AutoBid {
  enabled: boolean;
  limit: number;
  /** Se detuvo porque la siguiente puja pasaba del limite. */
  stopped: boolean;
  /** Por que se detuvo: limite alcanzado o saldo insuficiente al dispararse. */
  stoppedReason?: 'LIMIT_REACHED' | 'INSUFFICIENT_FUNDS' | null;
}

/** Todo lo que pinta la sala en vivo. Es lo que empuja el canal en tiempo real. */
export interface LiveRoom {
  room: Room;
  /** La ronda activa, o `null` entre rondas o con la sala cerrada. */
  round: Round | null;
  bids: Bid[];
  activity: RoomActivity[];
  autoBid: AutoBid;
  participants: number;
  /** Hora del servidor: el contador se calcula contra ella, no contra el reloj local. */
  serverTime: string;
}

export type MyBidStatus = 'WINNING' | 'OUTBID' | 'WON' | 'LOST';

export interface MyBid {
  id: string;
  itemId: string;
  itemName: string;
  imageUrl?: string | null;
  roomId: string;
  detail: string;
  amount: number;
  status: MyBidStatus;
  /** Cuanto se pujo por encima de quien mira, si lo superaron. */
  outbidBy: number | null;
  autoBidLimit: number | null;
}

export type NotificationKind =
  'OUTBID' | 'ROOM_SOON' | 'FOLLOW_ONLY' | 'WON' | 'LIMIT' | 'ROOM_CLOSED' | 'PICKUP_READY';

export interface AppNotification {
  id: string;
  pickupRoundId?: string;
  kind: NotificationKind;
  title: string;
  body: string;
  at: string;
  read: boolean;
  roomId: string | null;
}

export type RoomOutcome = 'WON' | 'LOST' | 'NO_BID';

export interface RoomSummary {
  roomId: string;
  roomName: string;
  items: number;
  participants: number;
  closedAt: string;
  rows: Array<{
    itemId: string;
    itemName: string;
    imageUrl?: string | null;
    position: number;
    outcome: RoomOutcome;
    amount: number | null;
    detail: string;
    /** Lo publico de la ronda, igual para todos: si se vendio y por cuanto. */
    result: 'AWARDED' | 'DESERTED' | null;
    finalPrice: number;
  }>;
  totalSpent: number;
  /** Lo publico de la sala: objetos vendidos, desiertos y lo recaudado. */
  sold: number;
  deserted: number;
  totalRaised: number;
}
