import type {
  AuctionableKind,
  RoomStatus,
  RoundStatus,
} from '../domain/room-status';

/**
 * Contratos de salas de ecilost-auction-service (HU-15), tal como viajan por la red.
 *
 * Los importes son **cadenas**: el servicio los guarda como `Decimal(18, 2)` y Prisma los
 * serializa como texto. Se muestran con `formatEcicoin`, sin pasarlos por un `number`.
 */

/** Una fila de `GET /rooms`. */
export interface RoomSummary {
  id: string;
  name: string;
  status: RoomStatus;
  startsAt: string;
  maximumCapacity: number;
  /** Estudiantes ya registrados. Nunca supera `maximumCapacity` (HU-16). */
  admittedCount: number;
  createdAt: string;
  roundCount: number;
  /** Si quien consulta ya esta registrado. Para el funcionario siempre es `false`. */
  isParticipant: boolean;
  /** Subastas dinamicas: si la ruleta de modalidades esta activa en la sala. */
  dynamicModesEnabled?: boolean;
  /** Si quien consulta programo la sala: solo el puede activar la ruleta y girarla. */
  isOwner?: boolean;
}

/**
 * Lo que va en una ronda. Solo el tipo y el identificador del catalogo: auction no guarda el
 * nombre para no desincronizarse, asi que la pantalla lo pide a catalog.
 */
export interface RoundEntry {
  kind: AuctionableKind;
  catalogId: string;
}

/**
 * Que cerro una ronda: el vencimiento de su reloj, una compra inmediata o, en una ronda
 * holandesa, alguien que pulso "Lo quiero".
 */
export type RoundCloseReason = 'EXPIRED' | 'BUY_NOW' | 'DUTCH_CLAIM';

/**
 * Como se juega una ronda (subastas dinamicas). `CLASSIC` es la subasta ascendente de
 * siempre y el modo de toda ronda que no paso por la ruleta.
 */
export type RoundMode = 'CLASSIC' | 'DUTCH' | 'SEALED' | 'MYSTERY';

/** Lo que puede marcar la ruleta. El comodin no es un modo: obliga a girar otra vez. */
export type SpinSegment = 'DUTCH' | 'SEALED' | 'MYSTERY' | 'WILDCARD';

/** Precios de una ronda holandesa. Importes como texto, igual que el resto. */
export interface DutchScheduleDetail {
  startPrice: string;
  floorPrice: string;
  step: string;
  intervalSeconds: number;
}

/** Sobre cerrado: cuantos sobres hay y el de quien consulta. Nunca los de los demas. */
export interface SealedDetail {
  count: number;
  mine: { amount: string; sealedAt: string } | null;
}

/** `POST /rooms/:id/rounds/:roundId/spin`. */
export interface SpinResult {
  roomId: string;
  roundId: string;
  position: number;
  segment: SpinSegment;
  /** `null` si salio comodin. */
  mode: RoundMode | null;
  wildcardSpins: number;
  canSpinAgain: boolean;
}

/** `GET /rounds/:id/sealed-results`: la apertura de sobres, cuando la ronda ya cerro. */
export interface SealedResultsDetail {
  roundId: string;
  sealedCount: number;
  ranking: Array<{ rank: number; amount: string; mine: boolean; winner: boolean }>;
  myRank: number | null;
}

export interface RoundDetail {
  id: string;
  /** Orden en la sala, desde 1. */
  position: number;
  status: RoundStatus;
  /** Precio minimo que fijo el funcionario: la primera puja debe alcanzarlo. */
  startingPrice: string;
  /** Arranca en `startingPrice` y sube con cada puja aceptada. */
  currentPrice: string;
  /**
   * Precio de compra inmediata (HU-24), o `null` si la ronda no la ofrece. Se puede comprar
   * mientras `currentPrice` no lo alcance.
   */
  buyNowPrice?: string | null;
  /** Si alguien ya pujo. Decide la puja minima: el precio minimo o el vigente + 100. */
  hasBids: boolean;
  /** Si quien consulta lidera la ronda. El servicio no publica quien es el lider. */
  isLeading: boolean;
  /** La mejor puja aceptada de quien consulta en esta ronda, o `null` si no pujo. */
  myHighestBid: string | null;
  /** Solo cerrada (HU-28): adjudicada a quien lideraba, o desierta si nadie pujo. */
  result: 'AWARDED' | 'DESERTED' | null;
  closedAt: string | null;
  /** Solo cerrada: si vencio su reloj o alguien la compro de inmediato (HU-24, HU-25). */
  closeReason?: RoundCloseReason | null;
  startedAt: string | null;
  endsAt: string | null;
  maximumEndsAt: string | null;
  entries: RoundEntry[];
  /** Subastas dinamicas. Los servicios anteriores no lo traen: se trata como `CLASSIC`. */
  mode?: RoundMode;
  /** La ruleta ya fijo el modo y no se puede volver a girar. */
  modeLocked?: boolean;
  /** Comodines seguidos en esta ronda. */
  wildcardSpins?: number;
  dutch?: DutchScheduleDetail | null;
  sealed?: SealedDetail | null;
}

/** `GET /rooms/:id`: la sala con sus rondas en orden. */
export interface RoomDetail extends Omit<RoomSummary, 'roundCount'> {
  rounds: RoundDetail[];
  /** Hora del servidor al responder: corrige el reloj local del contador. */
  serverTime?: string;
}

/** La puja automatica de quien consulta en la ronda vigente (HU-22). */
export interface AutoBidDetail {
  enabled: boolean;
  /** Decimal como texto, igual que los demas importes. */
  maximumAmount: string | null;
  stopped: boolean;
  stoppedReason: 'LIMIT_REACHED' | 'INSUFFICIENT_FUNDS' | null;
}

/** `GET /rooms/:id/state`: lo vigente para quien participa. */
export interface RoomStateDetail {
  serverTime: string;
  autoBid: AutoBidDetail | null;
}

export const ROOM_NAME_MAX = 80;

/** Cuerpo de `POST /rooms`. Operacion de funcionario. */
export interface ScheduleRoomRequest {
  name: string;
  maximumCapacity: number;
  /** ISO 8601. La sala se abre sola a esta hora y cierra el registro (HU-17). */
  startsAt: string;
  /** Subastas dinamicas: activa la ruleta de modalidades desde que se programa. */
  dynamicModes?: boolean;
  rounds: Array<{
    /**
     * El servicio admite varias entradas por ronda, pero la pantalla pone una sola: la sala
     * cambia de objeto en cada ronda, como la describe el deck.
     */
    entries: RoundEntry[];
    /** Entero: un ECICoin vale un peso colombiano. */
    startingPrice: number;
    /** Compra inmediata (HU-24): entero mayor que `startingPrice`. Sin el campo, no se ofrece. */
    buyNowPrice?: number;
  }>;
}
