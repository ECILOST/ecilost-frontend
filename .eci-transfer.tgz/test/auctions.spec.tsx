import { act, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it, vi } from 'vitest';
import {
  STAFF,
  STUDENT,
  createFakeAuthGateway,
  createFakeWalletGateway,
  createTestContainer,
  walletFixture,
} from './helpers/fake-gateways';
import { createDemoAuctionGateway } from '@/features/auctions/api/demo-auction.gateway';
import type { LiveRoom } from '@/features/auctions/model/auction';
import { renderApp } from './helpers/render-app';

/**
 * Pantallas de subasta sobre el adaptador de demostracion (sin rivales ni reloj propio).
 * Las salas de la semilla: 04 en curso con la persona dentro, 07 en curso sin ella, 05
 * programada y 02 cerrada.
 */
function student(availableBalance = '950.00') {
  return createTestContainer({
    auth: createFakeAuthGateway(STUDENT),
    wallet: createFakeWalletGateway({
      wallet: walletFixture({ availableBalance }),
    }),
  });
}

describe('Subastas', () => {
  it('la portada destaca lo que esta en vivo y lista lo proximo', async () => {
    renderApp({ route: '/', container: student() });

    expect(
      await screen.findByRole('heading', { name: 'Mochila negra' }),
    ).toBeInTheDocument();
    expect(
      screen.getByRole('heading', { name: 'Próximas subastas' }),
    ).toBeInTheDocument();
    expect(screen.getByRole('link', { name: /ver subastas/i })).toHaveAttribute(
      'href',
      '/subastas',
    );
  });

  it('el catalogo filtra por estado y busca sin importar tildes', async () => {
    renderApp({ route: '/subastas', container: student() });

    const name = (text: string) =>
      screen.queryByRole('heading', { name: text });
    await screen.findByRole('heading', { name: 'Calculadora Casio' });
    await userEvent.click(screen.getByRole('button', { name: 'En vivo' }));
    expect(name('Mochila negra')).toBeInTheDocument();
    expect(name('Calculadora Casio')).not.toBeInTheDocument();

    await userEvent.click(screen.getByRole('button', { name: 'Todos' }));
    await userEvent.type(
      screen.getByRole('searchbox', { name: /buscar/i }),
      'audifonos',
    );
    expect(name('Audífonos Sony')).toBeInTheDocument();
    expect(name('Mochila negra')).not.toBeInTheDocument();
  });

  it('pujar pide confirmacion con el saldo que queda y luego avisa que vas ganando', async () => {
    renderApp({ route: '/salas/sala-04', container: student('950.00') });

    await userEvent.click(
      await screen.findByRole('button', { name: /pujar 480 ecicoin/i }),
    );
    const confirm = await screen.findByRole('dialog', {
      name: 'Confirmar puja',
    });
    // En la sala 04 la persona ya lidera con 380: subir a 480 solo reserva 100 mas, asi que
    // quedan 950 - 100 = 850 (no 950 - 480 = 470, como se calculaba antes).
    expect(confirm).toHaveTextContent('480 ECICoin');
    expect(confirm).toHaveTextContent('ya tenías 380 ECICoin');
    expect(confirm).toHaveTextContent('850 ECICoin');
    expect(confirm).not.toHaveTextContent('470 ECICoin');

    await userEvent.click(
      within(confirm).getByRole('button', { name: /confirmar puja/i }),
    );
    expect(
      await screen.findByRole('dialog', { name: '¡Vas ganando!' }),
    ).toBeInTheDocument();
  });

  it('deja pujar una cantidad exacta, pero no por debajo de la minima', async () => {
    renderApp({ route: '/salas/sala-04', container: student('950.00') });

    const amount = await screen.findByLabelText(/otra cantidad/i);
    await userEvent.type(amount, '479');
    await userEvent.click(
      screen.getByRole('button', { name: /pujar esta cantidad/i }),
    );
    expect(amount).toHaveAccessibleDescription(/al menos 480 ECICoin/i);
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument();

    await userEvent.clear(amount);
    await userEvent.type(amount, '725');
    await userEvent.click(
      screen.getByRole('button', { name: /pujar esta cantidad/i }),
    );
    const confirm = await screen.findByRole('dialog', {
      name: 'Confirmar puja',
    });
    expect(confirm).toHaveTextContent('725 ECICoin');
  });

  it('sin saldo suficiente dice cuanto falta en lugar de enviar la puja', async () => {
    // Liderando con 380, subir a 480 necesita 100 mas: con 60 disponibles faltan 40.
    renderApp({ route: '/salas/sala-04', container: student('60.00') });

    await userEvent.click(
      await screen.findByRole('button', { name: /pujar 480 ecicoin/i }),
    );
    const dialog = await screen.findByRole('dialog', {
      name: 'Saldo insuficiente',
    });
    expect(dialog).toHaveTextContent('Te faltan');
    expect(dialog).toHaveTextContent('40 ECICoin');
    expect(
      within(dialog).getByRole('link', { name: 'Recargar ECICoin' }),
    ).toHaveAttribute('href', '/billetera');
  });

  it('pujar envia la ronda que se estaba viendo (HU-25)', async () => {
    const container = student('950.00');
    const placeBid = vi.spyOn(container.auctions, 'placeBid');
    renderApp({ route: '/salas/sala-04', container });

    await userEvent.click(
      await screen.findByRole('button', { name: /pujar 480 ecicoin/i }),
    );
    const confirm = await screen.findByRole('dialog', { name: 'Confirmar puja' });
    await userEvent.click(
      within(confirm).getByRole('button', { name: /confirmar puja/i }),
    );
    expect(placeBid).toHaveBeenCalledWith('sala-04', 'mochila-negra-round', 480);
  });

  it('si la sala pasa a otro objeto con el dialogo de puja abierto, lo cierra sin pujar (HU-25)', async () => {
    const container = student('950.00');
    const placeBid = vi.spyOn(container.auctions, 'placeBid');
    renderApp({ route: '/salas/sala-04', container });

    await userEvent.click(
      await screen.findByRole('button', { name: /pujar 480 ecicoin/i }),
    );
    expect(
      await screen.findByRole('dialog', { name: 'Confirmar puja' }),
    ).toBeInTheDocument();

    // La mochila se vende por compra inmediata mientras el dialogo sigue abierto.
    await act(async () => {
      await container.auctions.buyNow('sala-04', 'mochila-negra-round');
    });

    await waitFor(() =>
      expect(
        screen.queryByRole('dialog', { name: 'Confirmar puja' }),
      ).not.toBeInTheDocument(),
    );
    expect(placeBid).not.toHaveBeenCalled();
  });

  it('si otro participante compra lo que se estaba viendo, avisa que se vendio por compra inmediata (HU-25)', async () => {
    // Se mira la sala como la ve otro participante: la compra la hace la demo, pero para
    // quien mira la ronda no la gano el.
    const demo = createDemoAuctionGateway({ rivals: false, tickMs: 0 });
    const asOtherParticipant = (state: LiveRoom): LiveRoom => ({
      ...state,
      room: {
        ...state.room,
        rounds: state.room.rounds.map((round) =>
          round.closeReason === 'BUY_NOW'
            ? { ...round, wonByMe: false, leading: false }
            : round,
        ),
      },
    });
    const container = createTestContainer({
      auth: createFakeAuthGateway(STUDENT),
      wallet: createFakeWalletGateway({ wallet: walletFixture({ availableBalance: '950.00' }) }),
      auctions: {
        ...demo,
        liveRoom: async (roomId) => asOtherParticipant(await demo.liveRoom(roomId)),
        subscribe: (roomId, listener) =>
          demo.subscribe(roomId, (state) => listener(asOtherParticipant(state))),
      },
    });
    renderApp({ route: '/salas/sala-04', container });
    await screen.findByRole('button', { name: /pujar 480 ecicoin/i });

    await act(async () => {
      await demo.buyNow('sala-04', 'mochila-negra-round');
    });

    const sold = await screen.findByRole('dialog', {
      name: 'Vendido por compra inmediata',
    });
    expect(sold).toHaveTextContent('Mochila negra');
    expect(sold).toHaveTextContent('900');
    // Lideraba con 380: se le dice que su reserva se libera.
    expect(sold).toHaveTextContent('Se liberan');
    expect(screen.queryByRole('dialog', { name: '¡Ganaste!' })).not.toBeInTheDocument();
  });

  it('comprar ahora pide confirmacion y compra la ronda que se estaba viendo (HU-24)', async () => {
    const container = student('950.00');
    const buyNow = vi.spyOn(container.auctions, 'buyNow');
    renderApp({ route: '/salas/sala-04', container });

    await userEvent.click(
      await screen.findByRole('button', { name: /comprar ahora · 900/i }),
    );
    const confirm = await screen.findByRole('dialog', {
      name: 'Confirmar compra',
    });
    // Lidera con 380: comprar a 900 solo reserva 520 mas, asi que quedan 950 - 520 = 430.
    expect(confirm).toHaveTextContent('900 ECICoin');
    expect(confirm).toHaveTextContent('430 ECICoin');

    await userEvent.click(
      within(confirm).getByRole('button', { name: /confirmar compra/i }),
    );
    expect(buyNow).toHaveBeenCalledWith('sala-04', 'mochila-negra-round');
    expect(
      await screen.findByRole('dialog', { name: '¡Ganaste!' }),
    ).toBeInTheDocument();
  });

  it('no bloquea una mejora de la propia puja que si alcanza con el saldo', async () => {
    // Antes comparaba los 480 enteros contra 350 y decia "saldo insuficiente".
    renderApp({ route: '/salas/sala-04', container: student('350.00') });

    await userEvent.click(
      await screen.findByRole('button', { name: /pujar 480 ecicoin/i }),
    );
    expect(
      await screen.findByRole('dialog', { name: 'Confirmar puja' }),
    ).toHaveTextContent('250 ECICoin');
    expect(
      screen.queryByRole('dialog', { name: 'Saldo insuficiente' }),
    ).not.toBeInTheDocument();
  });

  it('la sala de espera muestra el logotipo provisional, no el texto "Campus universitario"', async () => {
    renderApp({ route: '/salas/sala-05', container: student() });

    await screen.findByRole('button', { name: 'Unirme a la sala' });
    expect(screen.queryByText('Campus universitario')).not.toBeInTheDocument();
    expect(document.querySelector('[aria-label="ECI Lost"]')).not.toBeNull();
  });

  it('quien no entro antes del inicio solo sigue la sala, sin boton de pujar', async () => {
    renderApp({ route: '/salas/sala-07', container: student() });

    expect(
      await screen.findByText(
        'El ingreso a esta sala cerró al iniciar la subasta',
      ),
    ).toBeInTheDocument();
    expect(
      await screen.findByText('Reloj inteligente', { selector: 'h2' }),
    ).toBeInTheDocument();
    expect(
      screen.queryByRole('button', { name: /pujar/i }),
    ).not.toBeInTheDocument();
    // El chat es de los participantes: quien sigue desde afuera no lo ve.
    expect(
      screen.queryByRole('heading', { name: 'Chat de la sala' }),
    ).not.toBeInTheDocument();
  });

  it('el participante chatea con la sala mientras la subasta esta en curso', async () => {
    const user = userEvent.setup();
    renderApp({ route: '/salas/sala-04', container: student() });

    const chat = within(
      (await screen.findByRole('heading', { name: 'Chat de la sala' }))
        .closest('section') as HTMLElement,
    );
    expect(await chat.findByText('¡Suerte a todos!')).toBeInTheDocument();

    await user.type(chat.getByLabelText('Mensaje'), '  Hola   sala ');
    await user.click(chat.getByRole('button', { name: 'Enviar' }));

    expect(await chat.findByText('Hola sala')).toBeInTheDocument();
    expect(chat.getByLabelText('Mensaje')).toHaveValue('');
  });

  it('en la sala de espera se puede unir antes del inicio', async () => {
    renderApp({ route: '/salas/sala-05', container: student() });

    await userEvent.click(
      await screen.findByRole('button', { name: 'Unirme a la sala' }),
    );
    expect(
      await screen.findByRole('button', { name: /ya estás dentro/i }),
    ).toBeDisabled();
    expect(screen.getByText('33/40')).toBeInTheDocument();
  });

  it('al cerrar la sala resume lo ganado, lo perdido y lo gastado', async () => {
    renderApp({ route: '/salas/sala-02', container: student() });

    expect(
      await screen.findByRole('heading', { name: 'La sala finalizó' }),
    ).toBeInTheDocument();
    expect(screen.getByText('Total gastado en la sala')).toBeInTheDocument();
    expect(screen.getByText('1.220')).toBeInTheDocument();
  });

  it('mis pujas separa las activas del historial', async () => {
    renderApp({ route: '/mis-pujas', container: student() });

    expect(await screen.findByText('Mochila negra')).toBeInTheDocument();
    await userEvent.click(screen.getByRole('tab', { name: 'Historial' }));
    expect(await screen.findByText('Mochila Totto')).toBeInTheDocument();
    expect(screen.queryByText('Mochila negra')).not.toBeInTheDocument();
  });

  it('las notificaciones se marcan como leidas y la campana deja de avisar', async () => {
    renderApp({ route: '/notificaciones', container: student() });

    expect(
      await screen.findByRole('link', { name: /notificaciones, 2 sin leer/i }),
    ).toBeInTheDocument();
    await userEvent.click(
      await screen.findByRole('button', { name: 'Marcar todas como leídas' }),
    );
    expect(
      await screen.findByRole('link', { name: 'Notificaciones' }),
    ).toBeInTheDocument();
  });

  it('un funcionario no entra a las pantallas de subasta: no puja', async () => {
    renderApp({
      route: '/subastas',
      container: createTestContainer({ auth: createFakeAuthGateway(STAFF) }),
    });

    expect(await screen.findByRole('alert')).toHaveTextContent(
      /solo los estudiantes pujan/i,
    );
  });
});
